import express, {Request, Response} from "express";

const app = express();
const PORT = process.env.PORT ?? 3000

app.use(express.json());


function armazenarJogadores(){
    
}

app.listen(PORT, () => console.log(`API em execução no URL: http://localhost:${PORT}`));
